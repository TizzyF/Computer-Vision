function P = calculateP_RANSAC(data_3D, data_2D, points_number, target_probability, e)
% data_3D is input 3D points set
% data_2D is input 2D points set
% points_number is the number of points selected from data set
% target_probability is the probability the the subset only contains inlier points
% e is the error rate of the data set

    % repeat times
    s = ceil(log(1-target_probability) / log(1-((1-e)^points_number)));
    
    % initilize inlier points number
    inlier_number = 0;
    % a vector to save the index of inlier points
    inlier_p = [];
    
    total_number = size(data_3D, 1);
    for t = 1 : s
        % create a V vector
        V = ones(12, 1);
        % pick N points from K points randomly
        seed = sort(randperm(total_number, points_number));
        % M matrix is used to save the selected 3D points
        M = zeros(points_number, 3);
        % m matrix is used to save the selected 2D points
        m = zeros(points_number, 2);
        
        for i = 1 : points_number
            M(i, :) = data_3D(seed(i), :);
            m(i, :) = data_2D(seed(i), :);
        end
        
        % use the second method in ppt
        [B, b] = create_B(M, m);
        Y = -1 * pinv(transpose(B) * B) * transpose(B) * b;
        factor = 1 / sqrt(Y(9)^2 + Y(10)^2 + Y(11)^2);
        
        for i = 1 : length(Y)
            V(i, 1) = Y(i, 1);
        end
        
        V = factor * V;
        % initialize the P matrix
        P = zeros(3, 4);
        for i = 1 : 3
            P(i, :) = V(i*4-3:i*4);
        end

        % the good matched points number
        [n, set] = match(data_3D, data_2D, P);
        if n > inlier_number
            inlier_number = n;
            inlier_p = set;
        end       
    end
    
    % create a V vector
    V = ones(12, 1);
    % total number of inlier points
    len = length(inlier_p);
    
    M_inlier = zeros(len, 3);
    m_inlier = zeros(len, 2);
    
    for i = 1 : len
        M_inlier(i, :) = data_3D(inlier_p(i), :);
        m_inlier(i, :) = data_2D(inlier_p(i), :);
    end
    
    [B, b] = create_B(M_inlier, m_inlier);
    Y = -1 * pinv(transpose(B) * B) * transpose(B) * b;
    factor = 1 / sqrt(Y(9)^2 + Y(10)^2 + Y(11)^2);
    
    for i = 1 : length(Y)
        V(i, 1) = Y(i, 1);
    end
    
    V = factor * V;
    P = zeros(3, 4);    
    
    for i = 1 : 3
        P(i, :) = V(i*4-3:i*4);
    end
end