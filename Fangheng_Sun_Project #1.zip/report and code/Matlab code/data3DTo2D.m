function m = data3DTo2D(data_3D, P)
    % lamda is the saclar in full perspective projection equation
    lamda = data_3D * transpose(P(3, 1:3)) + P(3, 4);
    length = size(data_3D, 1);
    % initialize an empty 
    tmp = zeros(length, 2);
    % compute the corresponding column value
    tmp(:, 1) = (data_3D * transpose(P(1, 1:3)) + P(1, 4)) ./ lamda;
    % compute the corresponding row value
    tmp(:, 2) = (data_3D * transpose(P(2, 1:3)) + P(2, 4)) ./ lamda;
    m = round(tmp, 0);
end