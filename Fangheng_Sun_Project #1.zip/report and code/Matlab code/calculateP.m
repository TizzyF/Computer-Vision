function P = calculateP(data_3D, data_2D, points_number)
    % create a V vector
    V = ones(12, 1);
    total_number = size(data_3D, 1);
    seeds = sort(randperm(total_number, points_number));
    % M matrix is used to save the selected 3D points
    M = zeros(length(seeds), 3);
    % m matrix is used to save the selected 2D points
    m = zeros(length(seeds), 2);
    
    for i = 1 : length(seeds)
        M(i, :) = data_3D(seeds(i), :);
        m(i, :) = data_2D(seeds(i), :);
    end
    
    % use the second method in ppt
    [B, b] = create_B(M, m);
    
    Y = -1 * pinv(transpose(B) * B) * transpose(B) * b;
    
    factor = 1 / sqrt(Y(9)^2 + Y(10)^2 + Y(11)^2);
    
    for i = 1 : length(Y)
        V(i, 1) = Y(i, 1);
    end
    
    V = factor * V;
    P = zeros(3, 4);
    
    for i = 1 : 3
        P(i, :) = V(i*4-3:i*4);
    end
    
    
end