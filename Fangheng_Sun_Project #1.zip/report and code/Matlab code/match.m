% n is inlier points number, m is inlier points index set
function [n, m] = match(input_3D, target_2D, P)
    % using P matrix to project 3D points to 2D points
    proj_2D = data3DTo2D(input_3D, P);
    % distance from source 2D points to target 2D points
    tmp = sqrt(sum(((proj_2D - target_2D).^2), 2));
    % m is inlier points index set
    m = [];
    
    for i = 1 : size(input_3D, 1)
        if tmp(i) > 10
            tmp(i) = 0;
        else
            tmp(i) = 1;
            m = horzcat(m, i);
        end
    end
    
    % n is inlier points number
    n = sum(tmp, 1);
end