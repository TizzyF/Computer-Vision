function [W, R, T] = computePara(P)
    W = zeros(3);
    R = zeros(3);
    T = zeros(3, 1);
    
    R(3, :) = P(3, 1:3); % r3
    T(3, 1) = P(3, 4); % tz
    W(1, 3) = P(1, 1:3) * transpose(R(3, :)); % c0
    W(2, 3) = P(2, 1:3) * transpose(R(3, :)); % r0
    W(1, 1) = sqrt(P(1, 1:3) * transpose(P(1, 1:3)) - W(1, 3)^2); % sxf
    W(2, 2) = sqrt(P(2, 1:3) * transpose(P(2, 1:3)) - W(2, 3)^2); % syf
    T(1, 1) = ( P(1, 4) - W(1, 3) * T(3, 1) ) / W(1, 1);
    T(2, 1) = ( P(2, 4) - W(2, 3) * T(3, 1) ) / W(2, 2);
    R(1, :) = ( P(1, 1:3) - W(1, 3) * R(3, :) ) / W(1, 1);
    R(2, :) = ( P(2, 1:3) - W(2, 3) * R(3, :) ) / W(2, 2);
end