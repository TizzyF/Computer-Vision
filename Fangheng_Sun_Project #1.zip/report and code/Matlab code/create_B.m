function [B, b] = create_B(M, m)
    tmp_B = zeros(2*size(M, 1), 11);
    tmp_b = zeros(2*size(M, 1), 1);
    for i = 1 : size(M, 1)
        tmp_B(2*i-1, 1:3) = M(i, :);
        tmp_B(2*i-1, 4) = 1;
        tmp_B(2*i-1, 9:11) = -1 * m(i, 1) * M(i, :);
        tmp_B(2*i, 5:7) = M(i, :);
        tmp_B(2*i, 8) = 1;
        tmp_B(2*i, 9:11) = -1 * m(i, 2) * M(i, :);
        
        tmp_b(2*i-1, 1) = -1 * m(i, 1);
        tmp_b(2*i) = -1 * m(i, 2);
    end
    
    B = tmp_B;
    b = tmp_b;
end