function data = readtxt(filepath) 
    data = dlmread(filepath);
end
